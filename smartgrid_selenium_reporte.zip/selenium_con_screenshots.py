
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os

# Crear carpeta para las capturas
os.makedirs("screenshots", exist_ok=True)

driver = webdriver.Chrome()
driver.get("https://edesursmartgird.netlify.app/")
driver.maximize_window()
wait = WebDriverWait(driver, 10)

def screenshot(nombre):
    time.sleep(1)
    driver.save_screenshot(f"screenshots/{nombre}.png")

time.sleep(3)
screenshot("01_inicio")

# Reportar fallo
reportar = wait.until(EC.element_to_be_clickable((By.CLASS_NAME, "report-button")))
reportar.click()
driver.switch_to.alert.send_keys("fallo")
driver.switch_to.alert.accept()
driver.switch_to.alert.send_keys("Un autobús chocó un poste de luz y ahora no hay red eléctrica")
driver.switch_to.alert.accept()
driver.switch_to.alert.accept()
screenshot("02_reportar_fallo")

# Reportar mantenimiento
reportar.click()
driver.switch_to.alert.send_keys("mantenimiento")
driver.switch_to.alert.accept()
driver.switch_to.alert.send_keys("Mantenimiento por cambio de poste de luz")
driver.switch_to.alert.accept()
driver.switch_to.alert.accept()
screenshot("03_reportar_mantenimiento")

# Navegar a secciones
driver.find_element(By.CSS_SELECTOR, "a[data-target='reportesHistoricos']").click()
screenshot("04_reportes_historicos")

driver.find_element(By.CSS_SELECTOR, "a[data-target='mantenimiento']").click()
screenshot("05_mantenimiento")

driver.find_element(By.CSS_SELECTOR, "a[data-target='alertasActivas']").click()
screenshot("06_alertas_activas")

driver.find_element(By.CSS_SELECTOR, "a[data-target='analisisPreventivo']").click()
screenshot("07_analisis_preventivo")

driver.find_element(By.CSS_SELECTOR, "a[data-target='estadoGeneral']").click()
screenshot("08_estado_general")

# Generar HTML simple con las capturas
with open("reporte.html", "w") as f:
    f.write("<html><head><title>Reporte de Prueba Selenium</title></head><body>")
    f.write("<h1>Reporte de Prueba Automatizada - Smart Grid EDESUR</h1>")
    for i, nombre in enumerate([
        "01_inicio", "02_reportar_fallo", "03_reportar_mantenimiento",
        "04_reportes_historicos", "05_mantenimiento", "06_alertas_activas",
        "07_analisis_preventivo", "08_estado_general"
    ]):
        f.write(f"<h2>Escenario {i+1}: {nombre.replace('_', ' ').capitalize()}</h2>")
        f.write(f"<img src='screenshots/{nombre}.png' width='800'><br><br>")
    f.write("</body></html>")

print("✅ Flujo completo ejecutado con capturas. Revisa el archivo reporte.html.")
driver.quit()
